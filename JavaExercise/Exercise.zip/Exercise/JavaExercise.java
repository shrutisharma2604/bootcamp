public class JavaExercise{
    public static void main(String[] args) {
        String str="Hello world";
        String str1=str.replace("world","shruti");
        System.out.println(str1);
        String str2=str.replace("He","ji");
        System.out.println(str2);
    }
}
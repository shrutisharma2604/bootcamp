public class JavaExercise2{
        public static void main(String[]args){
        String string="HelloHiiiHey";
        int string1=string.length()-string.replace("H","").length();
        System.out.println(string1);
        }
}